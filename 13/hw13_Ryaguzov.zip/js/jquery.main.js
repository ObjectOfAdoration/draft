$(function () {
    jcf.replaceAll();
});